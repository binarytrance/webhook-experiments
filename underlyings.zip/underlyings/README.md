## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)

### App Requirements

-   create a new create-react-app
-   ![create an HLD](https://i.imgur.com/bbsnrzd.png)
-   install redux and redux toolkit (finish max's tut), react query
-   create the routes
-   setup react-query
-   add loading icon
-   handle errors
    -   list out all underlyings
        -   /token - list out all derivative of individual underlying
-   fetch and render list of underlyings
-   fetch and show derivatives for underlying
-   Poll underlyings api every 10 minutes.
-   Poll derivatives api every 30 seconds.
-   use websockets to subscribe to price of each underlying
-   use websockets to subscribe to price of each derivative

-   subscribe on page mount
-   close the socket on unmount
-   guage the requirement of redux. Implement either way
-   handle connection disconnects and re-connections
-   test for network errors
-   add tests

### Improvements/Considerations

-   apply a middleware which establishes the websocket connect and decouple compnents with the socket logic
-   implement web sockets with react query and chuck redux?
-   what is the quote https api for? is it to fetch the prices for each individual token first and then using websockets, we subscribe to the prices? That can very well be implemented but i am hard pressed for time
-   right now i am updating the store everytime i receive any price data from the subscription. maybe i don't do that if the price for a token hasn't changed from its previous state?
-   improve socket close logic
-   add a table structure in the UI
