// app wide api calls
import { useQuery } from "react-query";
import fetchWithError from "../helpers/fetchWithError";

// query functions
const fetchQuotes = token => {
    const quotes = fetchWithError(`https://prototype.sbulltech.com/api/quotes/${token}`);
    return quotes;
};

// useQuery custom hooks
export const useFetchQuotes = token => {
    const quotesQuery = useQuery(["quotes", token], () => fetchQuotes(token), {
        onSuccess: data => {
            console.log(data, "inside usequery");
        }
    });
    return quotesQuery;
};
