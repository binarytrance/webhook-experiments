import React, { useMemo } from "react";
import PropTypes from "prop-types";
import { PacmanLoader } from "react-spinners";
import { Link } from "react-router-dom";
import useSubscriveToHooks from "../../CustomHooks/useSubscribeToHooks";
import { useSelector } from "react-redux";

const List = ({ isError, isLoading, list }) => {
    const getTokens = () => {
        // create an array of takens from the available list of derivatives/underlyings
        const tokens = list?.map(derivative => derivative.token);
        return tokens;
    };
    const tokens = useMemo(getTokens, [list]);
    // custom hook responsible for starting the websocket
    useSubscriveToHooks(tokens);
    const tokensWithPrices = useSelector(state => state.quotes);
    if (isError) {
        return null;
    }
    if (isLoading) {
        return <PacmanLoader color="#FF5000" size="15" />;
    }
    return (
        <ul>
            {list.map(({ token, symbol, underlying, expiry }) => (
                <li key={token} className="flex justify-between my-2">
                    {!expiry ? underlying : symbol}{" "}
                    <span>{tokensWithPrices[token]?.toFixed(2)}</span>
                    {!expiry ? (
                        <Link to={`/derivatives/${token}`} className="underline">
                            Show Derivative
                        </Link>
                    ) : null}
                </li>
            ))}
        </ul>
    );
};

List.propTypes = {
    isLoading: PropTypes.bool,
    isFetching: PropTypes.bool,
    list: PropTypes.array
};

export default List;
