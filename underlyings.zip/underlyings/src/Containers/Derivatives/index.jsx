import React from "react";

import { useNavigate, useParams } from "react-router-dom";
import { PacmanLoader } from "react-spinners";
import List from "../../Components/List";
import { useFetchDerivatives } from "./Queries";

const Derivatives = () => {
    const params = useParams();
    const navigate = useNavigate();
    const {
        isError,
        isFetching,
        isLoading,
        data: derivativesData
    } = useFetchDerivatives(params.token);
    return (
        <div className="flex flex-col">
            <button className="mr-auto" onClick={() => navigate(-1)}>
                Back to Derivatives
            </button>
            <div className="flex  my-4">
                <h1 className="text-xl font-bold mr-2">Derivatives</h1>
                {isFetching && !isLoading && <PacmanLoader color="#FF5000" size="10" />}
            </div>
            <List isError={isError} isLoading={isLoading} list={derivativesData?.payload} />
        </div>
    );
};

export default Derivatives;
