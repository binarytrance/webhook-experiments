import { useQuery } from "react-query";
import fetchWithError from "../../../helpers/fetchWithError";

// query functions
const fetchDerivatives = token => {
    const allDerivatives = fetchWithError(
        `https://prototype.sbulltech.com/api/derivatives/${token}`
    );
    return allDerivatives;
};

// useQuery custom hooks
export const useFetchDerivatives = token => {
    const allDerivativesQuery = useQuery(["derivatives", token], () => fetchDerivatives(token), {
        staleTime: 1000 * 30,
        refetchInterval: 1000 * 30
    });
    return allDerivativesQuery;
};
