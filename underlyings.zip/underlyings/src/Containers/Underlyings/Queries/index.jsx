import { useQuery } from "react-query";
import fetchWithError from "../../../helpers/fetchWithError";

// query functions
const fetchUnderlyings = () => {
    const allUnderlyings = fetchWithError("https://prototype.sbulltech.com/api/underlyings");
    return allUnderlyings;
};

// useQuery custom hooks
export const useFetchUnderlyings = () => {
    const allUnderlyingsQuery = useQuery(["underlyings"], () => fetchUnderlyings(), {
        staleTime: 1000 * 60 * 10,
        refetchInterval: 1000 * 60 * 10
    });
    return allUnderlyingsQuery;
};
