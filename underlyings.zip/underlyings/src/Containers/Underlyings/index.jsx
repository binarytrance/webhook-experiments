import React from "react";
import { PacmanLoader } from "react-spinners";
import { useFetchUnderlyings } from "./Queries";
import List from "../../Components/List";

const Underlyings = () => {
    const { isError, isFetching, isLoading, data: underlyingsData } = useFetchUnderlyings();
    return (
        <div className="flex flex-col">
            <div className="flex my-4">
                <h1 className="text-xl mr-2 font-bold">Underlyings</h1>
                {isFetching && !isLoading && <PacmanLoader color="#FF5000" size="10" />}
            </div>
            <List isError={isError} isLoading={isLoading} list={underlyingsData?.payload} />
        </div>
    );
};

export default Underlyings;
