import { createSlice } from "@reduxjs/toolkit";

const initialState = { quotes: {} };

const quotesSlice = createSlice({
    name: "quotes",
    initialState,
    reducers: {
        updatePrice(state, action) {
            console.log({ action });
            state.quotes[action.payload.token] = action.payload.price;
        }
    }
});

export const quotesActions = quotesSlice.actions;

export default quotesSlice;
