import { Route, Routes } from "react-router-dom";
import Underlyings from "./Containers/Underlyings";
import Derivatives from "./Containers/Derivatives";

function App() {
    return (
        <div className="App max-w-screen-sm m-auto py-5">
            <Routes>
                <Route path="/" element={<Underlyings />} />
                <Route path="/derivatives/:token" element={<Derivatives />} />
                <Route path="/*" element={<p>404 page</p>} />
            </Routes>
        </div>
    );
}

export default App;
