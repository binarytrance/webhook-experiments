import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { quotesActions } from "../store/quotes-slice";

export default function useSubscriveToHooks(tokens) {
    const dispatch = useDispatch();

    useEffect(() => {
        const tokensObj = {};

        let socket = new WebSocket("wss://prototype.sbulltech.com/api/ws");
        const connect = () => {
            let outgoingMessage = {
                msg_command: "subscribe",
                data_type: "quote",
                tokens: tokens
            };
            socket.onopen = e => {
                socket.send(JSON.stringify(outgoingMessage));
            };
            socket.onmessage = event => {
                let message = JSON.parse(event.data);
                try {
                    if (message?.payload?.token) {
                        tokensObj[message?.payload?.token] = message?.payload?.price;

                        dispatch(
                            quotesActions.updatePrice({
                                token: message?.payload?.token,
                                price: message?.payload?.price
                            })
                        );
                    }
                } catch (err) {
                    console.log(err);
                }
            };
            socket.onclose = event => {
                console.log(
                    "Socket is closed. Reconnect will be attempted in 1 second.",
                    JSON.stringify(event)
                );
                setTimeout(function () {
                    connect();
                }, 1000);
            };
            socket.onerror = error => {
                console.error("Socket encountered error: ", error.err_msg, "Closing socket");
                socket.close();
            };
        };
        connect();
        return () => socket.close();
    }, [tokens, dispatch]);

    // return tokensWithPrices;
}
