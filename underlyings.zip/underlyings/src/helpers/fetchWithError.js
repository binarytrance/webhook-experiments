export default async function fetchWithError(url, options) {
    const response = await fetch(url, options);
    if (response.status === 200 || response.status === 201) {
        const result = await response.json();
        console.log({ result });
        // if server returns a json with error inside it but with a status 200
        if (
            (result.sucess !== undefined && !result.success) ||
            (result.data_type !== undefined && result.data_type !== "quote")
        ) {
            throw new Error(result.err_msg);
        }
        return result;
    }
    throw new Error(
        `Error - ${response.status}: ${
            response.statusText ? response.statusText : "Something went wrong."
        }`
    );
}
